# FCC: Tribute Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/teaddict41/pen/GRxEmpm](https://codepen.io/teaddict41/pen/GRxEmpm).

